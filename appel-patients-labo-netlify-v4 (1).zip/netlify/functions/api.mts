import { getStore } from "@netlify/blobs";
import type { Config, Context } from "@netlify/functions";

/*
 * API de l'appel des patients.
 * Tout l'état (patients, réglages, compteur) tient dans un seul petit document
 * JSON. Chaque écriture est conditionnelle (ETag) et rejouée en cas de conflit,
 * ce qui suffit largement pour le volume d'un laboratoire.
 */
type Patient = {
  hasAudio?: boolean; audioAt?: number; audioMime?: string; infoAt?: number; infoMime?: string;
  id: string; num: number; code: string; civilite: string; nom: string; prenom: string;
  prononciation: string; status: "file" | "absent" | "enregistre" | "pret" | "retire";
  examens?: string[]; dureeMin?: number; dureeMax?: number; prelevedAt?: number | null;
  appelAt?: number | null; appelReq?: number; appelMime?: string; hasAppel?: boolean; appelCount?: number; absentAt?: number | null;
  createdAt: number; readyAt: number | null; retiredAt: number | null; announceReq?: number;
};
type DB = { patients: Patient[]; settings: Record<string, unknown>; counter: number };

const KEY = "state";
const CIVS = ["Monsieur", "Madame", "Mademoiselle", "Enfant", "Bébé"];
const SETTING_KEYS = ["centre", "salle", "prefixe", "intervalMin", "maxHeures", "silenceDebut", "silenceFin", "vitesse", "repetitions", "appel2Min", "appel3Min", "videoDelaiSec", "sallePrel", "margeMin", "attenteSec", "pin"];
const store = () => getStore({ name: "appel-labo", consistency: "strong" });
const audioStore = () => getStore({ name: "appel-labo-audio", consistency: "strong" });
const str = (v: unknown, max = 80) => String(v == null ? "" : v).trim().slice(0, max);
const sfx = (kind: unknown) => kind === "info" ? "_info" : kind === "appel" ? "_appel" : "";
const num = (v: unknown, lo: number, hi: number) => Math.max(lo, Math.min(hi, Math.round(Number(v) || 0)));
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" } });

async function load(): Promise<{ db: DB; etag: string | null }> {
  const e = await store().getWithMetadata(KEY, { type: "json" });
  if (e === null) return { db: { patients: [], settings: {}, counter: 0 }, etag: null };
  return { db: e.data as DB, etag: e.etag ?? null };
}

async function mutate<T>(fn: (db: DB) => T | { error: string; status: number }): Promise<T | { error: string; status: number }> {
  for (let i = 0; i < 10; i++) {
    const { db, etag } = await load();
    const res = fn(db);
    if (res && typeof res === "object" && "error" in (res as object)) return res;
    const limit = Date.now() - 90 * 24 * 3600 * 1000;
    const old = Date.now() - 2 * 24 * 3600 * 1000;
    db.patients = db.patients.filter(p => !(p.status === "retire" && p.retiredAt && p.retiredAt < limit) && !((p.status === "file" || p.status === "absent") && p.createdAt < old));
    const r = etag ? await store().setJSON(KEY, db, { onlyIfMatch: etag }) : await store().setJSON(KEY, db, { onlyIfNew: true });
    if (r.modified) return res;
    await new Promise(ok => setTimeout(ok, 40 + Math.random() * 120));
  }
  throw new Error("Trop d'écritures simultanées, réessayez.");
}

const isAuth = (db: DB, pin: string | null) => !db.settings.pin || String(pin || "") === String(db.settings.pin);
function view(db: DB, auth: boolean, etag: string | null) {
  const { pin, ...settings } = db.settings;
  return {
    etag, serverTime: Date.now(), pinRequired: !!pin, auth, settings,
    // sans PIN valide (écran TV) : jamais de nom de famille, uniquement les résultats prêts
    // l'écran TV reçoit aussi les patients en attente qui ont un message vocal récent (15 min)
    // + les patients appelés en salle de prélèvement (15 min) et ceux en cours d'analyse (12 h), pour le temps d'attente
    patients: auth ? db.patients : db.patients.filter(p => {
      const t = Date.now();
      if (p.status === "pret") return true;
      if (p.status === "enregistre") return !!((p.infoAt && t - p.infoAt < 15 * 60000) || (p.prelevedAt && t - p.prelevedAt < 12 * 3600000));
      if (p.status === "file") return !!(p.appelAt && t - Math.max(p.appelAt, p.appelReq || 0) < 15 * 60000);
      return false;
    }).map(({ nom, ...p }) => p)
  };
}
function fmtCode(db: DB, n: number) {
  const x = ((n - 1) % 9999) + 1;
  return (str(db.settings.prefixe, 3) || "L") + "-" + String(x).padStart(4, "0");
}

export default async (req: Request, _context: Context) => {
  const url = new URL(req.url);
  const path = url.pathname.replace(/\/+$/, "");
  const pin = req.headers.get("x-pin");
  try {
    const ma = path.match(/^\/api\/audio\/([\w-]+)$/);
    if (req.method === "GET" && ma) {
      const e = await audioStore().getWithMetadata(ma[1] + sfx(url.searchParams.get("kind")), { type: "arrayBuffer" });
      if (e === null) return json({ error: "audio absent" }, 404);
      return new Response(e.data as ArrayBuffer, { headers: { "content-type": String((e.metadata as any)?.mime || "audio/webm"), "cache-control": "no-store" } });
    }
    if (req.method === "GET" && path === "/api/state") {
      const known = url.searchParams.get("etag");
      if (known) {
        const meta = await store().getMetadata(KEY);
        if (meta && meta.etag === known) return new Response(null, { status: 204, headers: { "cache-control": "no-store" } });
      }
      const { db, etag } = await load();
      // l'étiquette inclut le niveau d'accès, pour qu'un changement de PIN renvoie l'état complet
      return json(view(db, isAuth(db, pin), etag));
    }

    if (req.method !== "POST") return json({ error: "Méthode non permise" }, 405);
    let body: Record<string, unknown> = {};
    try { body = await req.json(); } catch { body = {}; }

    // contrôle du PIN sur l'état courant
    const current = await load();
    if (!isAuth(current.db, pin)) return json({ error: "PIN invalide" }, 401);

    if (path === "/api/patients") {
      const nom = str(body.nom).toUpperCase(), prenom = str(body.prenom);
      if (!nom || !prenom) return json({ error: "Nom et prénom obligatoires" }, 400);
      const out = await mutate(db => {
        db.counter = (db.counter || 0) + 1;
        const pat: Patient = {
          id: Date.now().toString(36) + Math.random().toString(36).slice(2, 8),
          num: db.counter, code: fmtCode(db, db.counter),
          civilite: CIVS.includes(String(body.civilite)) ? String(body.civilite) : "Monsieur",
          nom, prenom, prononciation: str(body.prononciation),
          status: body.status === "file" ? "file" : "enregistre", createdAt: Date.now(), readyAt: null, retiredAt: null,
          examens: Array.isArray(body.examens) ? (body.examens as unknown[]).slice(0, 20).map(x => str(x, 40)).filter(Boolean) : [],
          dureeMin: num(body.dureeMin, 0, 4320), dureeMax: num(body.dureeMax, 0, 4320)
        };
        db.patients.push(pat);
        return pat;
      });
      return json(out);
    }

    if (ma) {
      const b64 = String(body.data || "");
      const bin = Uint8Array.from(atob(b64), c => c.charCodeAt(0));
      if (!bin.length || bin.length > 2e6) return json({ error: "Audio invalide" }, 400);
      const mime = str(body.mime, 60) || "audio/webm";
      const info = body.kind === "info", appel = body.kind === "appel";
      await audioStore().set(ma[1] + sfx(body.kind), bin.buffer as ArrayBuffer, { metadata: { mime } });
      const out = await mutate(db => {
        const pat = db.patients.find(x => x.id === ma[1]);
        if (!pat) return { error: "Patient introuvable", status: 404 };
        if (info) { pat.infoAt = Date.now(); pat.infoMime = mime; }
        else if (appel) { pat.appelAt = Date.now(); pat.appelMime = mime; pat.hasAppel = true; }
        else { pat.hasAudio = true; pat.audioAt = Date.now(); pat.audioMime = mime; }
        return { ok: true };
      });
      if (out && typeof out === "object" && "error" in out) return json({ error: (out as any).error }, (out as any).status);
      return json({ ok: true });
    }

    const m = path.match(/^\/api\/patients\/([\w-]+)$/);
    if (m) {
      if (body.supprimer === true) {
        const out = await mutate(db => {
          const i = db.patients.findIndex(x => x.id === m[1]);
          if (i < 0) return { error: "Patient introuvable", status: 404 };
          db.patients.splice(i, 1);
          return { ok: true };
        });
        if (out && typeof out === "object" && "error" in out) return json({ error: (out as any).error }, (out as any).status);
        await Promise.all(["", "_info", "_appel"].map(k => audioStore().delete(m[1] + k).catch(() => {})));
        return json({ ok: true });
      }
      const out = await mutate(db => {
        const pat = db.patients.find(x => x.id === m[1]);
        if (!pat) return { error: "Patient introuvable", status: 404 };
        const t = Date.now();
        if (body.status === "pret") { pat.readyAt = body.readyAt ? Math.min(Number(body.readyAt), t) : t; pat.retiredAt = null; pat.status = "pret"; }
        else if (body.status === "retire") { pat.status = "retire"; pat.retiredAt = t; }
        else if (body.status === "enregistre") { pat.status = "enregistre"; pat.readyAt = null; pat.retiredAt = null; }
        else if (body.status === "file") { pat.status = "file"; pat.absentAt = null; }
        else if (body.status === "absent") { pat.status = "absent"; pat.absentAt = t; }
        if ("announceReq" in body) pat.announceReq = t;
        if ("appelReq" in body) pat.appelReq = t;
        // horodatages : null = effacer, sinon heure du serveur
        (["prelevedAt", "appelAt"] as const).forEach(k => { if (k in body) pat[k] = body[k] == null ? null : t; });
        if ("hasAppel" in body) pat.hasAppel = !!body.hasAppel;
        if ("appelCount" in body) pat.appelCount = num(body.appelCount, 0, 99);
        if (Array.isArray(body.examens)) pat.examens = (body.examens as unknown[]).slice(0, 20).map(x => str(x, 40)).filter(Boolean);
        if ("dureeMin" in body) pat.dureeMin = num(body.dureeMin, 0, 4320);
        if ("dureeMax" in body) pat.dureeMax = num(body.dureeMax, 0, 4320);
        if ("civilite" in body && CIVS.includes(String(body.civilite))) pat.civilite = String(body.civilite);
        (["nom", "prenom", "prononciation"] as const).forEach(k => { if (k in body) pat[k] = str(body[k]); });
        return pat;
      });
      if (out && typeof out === "object" && "error" in out) return json({ error: (out as any).error }, (out as any).status);
      return json(out);
    }

    if (path === "/api/settings") {
      await mutate(db => {
        SETTING_KEYS.forEach(k => { if (k in body) db.settings[k] = typeof body[k] === "number" ? body[k] : str(body[k], 120); });
        if (Array.isArray(body.examens)) db.settings.examens = (body.examens as any[]).slice(0, 60).map(e => ({ nom: str(e && e.nom, 40), min: num(e && e.min, 0, 4320) })).filter(e => e.nom && e.min);
        if (Array.isArray(body.videos)) db.settings.videos = (body.videos as any[]).slice(0, 30).map(v => ({ titre: str(v && v.titre, 80), url: str(v && v.url, 300) })).filter(v => /^https?:\/\//.test(v.url));
        return { ok: true };
      });
      return json({ ok: true });
    }

    return json({ error: "Introuvable" }, 404);
  } catch (e) {
    return json({ error: String((e as Error).message || e) }, 500);
  }
};

export const config: Config = { path: "/api/*" };
