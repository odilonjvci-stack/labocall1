# Appel des patients – version en ligne (Netlify)

Ce dossier se déploie tel quel sur Netlify : le site (public/) + l'API (netlify/functions/api.mts) + le stockage Netlify Blobs. Aucun ordinateur n'est nécessaire au centre.

Adresses une fois en ligne (exemple : https://appel-patients-labo.netlify.app) :
- Prélèvement : /#prelevement — Laboratoire : /#labo — Écran TV : /#tv — Réglages : /#reglages

Les téléphones et la TV se mettent à jour toutes les 4 secondes.
Pensez à définir un code PIN dans Réglages : le site est public sur Internet.

Nouveau (v4) :
- Prélèvement : enregistrement du bulletin avec les examens et leur durée, file d'attente par ordre d'arrivée, appel vocal en salle de prélèvement, absents à rappeler, suppression d'un patient enregistré par erreur.
- Après « Prélevé », le patient passe automatiquement au Laboratoire, et la TV affiche son temps d'attente estimé.
- Les durées des examens se modifient dans Réglages → Examens et durées.
